﻿/* Énumération représentant une direction sur une dimension
 * 
 * Créé par Charles Lachance
 */ 
//<Charles Lachance>
namespace TP3
{
  enum Direction
  {
    Right = 1,
    Left = -1,
    Undefined = 0
  }
}
//</Charles Lachance>