﻿/* Énumération représentant le résultat de la fin de la partie
 * 
 * Créé par Charles Lachance
 */ 
//<Charles Lachance>
namespace TP3
{
  enum EndGameResult
  {
    GAME_CONTINUE,
    GAME_LOST
  }
}
//</Charles Lachance>